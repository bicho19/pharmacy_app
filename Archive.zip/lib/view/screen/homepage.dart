import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:kmedica_pfe/config/constantes.dart';
import 'package:kmedica_pfe/config/widget/category_card.dart';
import 'package:kmedica_pfe/view/screen/patientscreen.dart';
import 'package:kmedica_pfe/view/screen/statumedscreen.dart';
import 'package:kmedica_pfe/view/screen/dosescreen.dart';
//import 'bottonbar.dart';
import 'medicamentlist.dart';

class MyApp extends StatelessWidget {
  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Kmedica',
      theme: ThemeData(
        fontFamily: "Cairo",
        scaffoldBackgroundColor: kBackgroundColor,
        textTheme: Theme.of(context).textTheme.apply(displayColor: kTextColor),
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      
      
    //  bottomNavigationBar: BottomBar(),
     // body: Stack(
        
        //children: <Widget>[
          //Container(
            
           // decoration: BoxDecoration(
              //color: Color(0xFFF5CEB8),
             // image: DecorationImage(
                //alignment: Alignment.centerLeft,
                //image: AssetImage("assets/images/homepage.png"),
                //fit: BoxFit.cover

              //),
            //),
            body:AnnotatedRegion<SystemUiOverlayStyle>(
        value:SystemUiOverlayStyle.light,
        child:Stack(
          children:<Widget>[
            Container(
              height:double.infinity,
              width:double.infinity,
              decoration:BoxDecoration(
                gradient:LinearGradient(
                  begin:Alignment.topCenter,
                  end:Alignment.bottomCenter,
                  colors: [
                    Color(0xffA7FFEB),
                    Color(0xff64FFDA),
                    Color(0xff18FFFF),
                    Color(0xff00E5FF),
                  ]
                  ),
              ),
            ),
          SafeArea(
            child: Container(
                padding: EdgeInsets.only(top: 15, left: 20, right:20),
                color: Color(0xFF80DEEA).withOpacity(.20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    RichText(
                      text: TextSpan(
                          text: " healthy home",
                          style: TextStyle(
                            fontSize: 30,
                            letterSpacing: 2,
                            color:  Colors.blueGrey[700],
                          ),
                            )
                          
                          ),
                    
                  Expanded(
                    child: GridView.count(
                      crossAxisCount: 2,
                      childAspectRatio: .85,
                      crossAxisSpacing: 20,
                      mainAxisSpacing: 20,
                      children: <Widget>[
                        CategoryCard(
                          title: "calculate the dose",
                  
                          press: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) {
                                return DoseScreen();
                              }),
                            );
                          },
                        ),
                        CategoryCard(
                          title: "explore the list of medications",
                          
                          press: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) {
                                return MedicamentScreen();
                              }),
                            );
                          },
                        ),
                           
        
      
                        CategoryCard(
                          title: "explore the patient list",
                          press: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) {
                                return PatientsScreen();
                              }),
                            );
                          },
                        ),
                        CategoryCard(
                          title: "medication status",
                          
                          press: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) {
                                return StatuMedScreen();
                              }),
                            );
                          },
                        ),
                      
                     /* shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18.0),
                        ),

                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Icon(
                              Icons.history,
                              color: Colors.tealAccent,
                              size: 48.0,
                            ),
                            SizedBox(
                              width: 40.0,
                            ),
                            Text(
                              'Historique',
                              style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.black54,
                                  fontWeight: FontWeight.w400),
                              textAlign: TextAlign.center,
                            )
                          ],
                        
                        ),*/
                     ],
                    )
                    ),
                 ],
                
                )
            )
          )
          ],
            ),
      ),
    );
  }
}

