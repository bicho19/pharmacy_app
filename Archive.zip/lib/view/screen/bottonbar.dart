/*import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:kmedica_pfe/config/constantes.dart';
import 'package:kmedica_pfe/view/screen/liste_history.dart';
class BottomBar extends StatelessWidget {
  const BottomBar({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
      height: 80,
      color: Color(0xFFE0F7FA),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
         
          BottomItem(
            title: "History",
            isActive: true,
            press: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) {
                                return ListHistory();
                              }
                              
                              ),
            
            
          
         
        ],
      ),
    );
  }
}

class BottomItem extends StatelessWidget {
 
  final String title;
  final Function press;
  final bool isActive;
  const BottomItem({
    Key key,
  
    this.title,
    this.press,
    this.isActive = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: press,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
        
          Text(
            title,
            style: TextStyle(color: isActive ? kActiveIconColor : kTextColor),
          ),
        ],
      ),
    );
  }
}
*/