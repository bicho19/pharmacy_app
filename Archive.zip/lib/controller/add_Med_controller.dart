import 'package:flutter/material.dart';

class add_Med_ctrl extends StatefulWidget {
  @override
  _add_Med_ctrlState createState() => _add_Med_ctrlState();
}

final code_med_ctrl = TextEditingController();
final nom_ctrl = TextEditingController();
final laboratoire_ctrl = TextEditingController();
final quantite_ctrl = TextEditingController();

class _add_Med_ctrlState extends State<add_Med_ctrl> {
  @override
  void dispose() {
    // Clean up the controller when the widget is disposed. pour allouer la ram
    code_med_ctrl.dispose();
    nom_ctrl.dispose();
    laboratoire_ctrl.dispose();
    quantite_ctrl.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
