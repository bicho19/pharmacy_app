import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
const kBackgroundColor = Color(0xFFF8F8F8);
const kActiveIconColor = Color(0xFFE68342);
const kTextColor = Color(0xFFB6C7D1);
const kBlueLightColor = Color(0xFFF8F8F8);
const kBlueColor = Color(0xFF64FFDA);
const kShadowColor = Color(0xFFE6E6E6);
class Palette {
 static const Color iconColor = Color(0xFFB6C7D1);
 static const Color activeColor = Color(0xff37474F);
 static const Color textColor1 = Color(0XFFA7BCC7);
 static const Color textColor2 = Color(0XFF9BB3C0);
 static const Color facebookColor = Color(0xFF3B5999);
 static const Color googleColor = Color(0xFFDE4B39);
 static const Color backgroundColor = Color(0xFFE0F7FA);
}