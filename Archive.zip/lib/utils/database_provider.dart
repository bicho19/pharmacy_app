import 'package:kmedica_pfe/moodle/Medecin.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DBProvider {
  Database _database;

  DBProvider._();

  static final DBProvider db = DBProvider._();

  /// ************
  /// Tables
  /// ******

//la declaration des attributs des tableaux pour eviter de tamber en erreur d'ortographe
  //tableau medecin=============================================
  final String tableMedecin = 'tableMedecin';
  final String _columnid = 'id';
  final String _columnusername = 'username';
  final String _columnnompassword = 'password';

//tableau medicament=============================================
  final String tableMedicament = 'tableMedicament';
  final String columncode_Med = 'code_medicament';
  final String columnnom_Med = 'nom';
  final String columnlaboratoire = 'laboratoire';
  final String columnquantite = 'quantite';

  //tableau Regles==========================================
  final String tableregles = 'Regles';
  final String id_reg = 'id';
  final String columnmin_val = 'min_val';
  final String columnmax_val = 'max_val';

  //tableau patient============================================================
  final String tablepatient = 'tablePatient';
  final String columnIdPatient = 'id_patient';
  final String columnnom_patient = 'nom_patient';
  final String columnprenom_patient = 'prenom_patient';
  final String columnage = 'age';
  final String columnPoids = 'poids';
  final String columnsex = 'sex';
  final String adresse = 'adresse';
  final String columnposologie = 'posologie';
  final String columnreduction = 'reduction';

  //les cle etrangers========================================================
  final String FKmedid = 'FKmedId';
  final String FKmedid2 = 'FKmedid2';

  final String FKpatientid = 'FKpatientid';

  Future<Database> get database async {
    if (_database != null) return _database;
    // if _database is null we instantiate it
    _database = await initDB();
    return _database;
  }

  initDB() async {
    print("InitDB...");
    String databasePath = await getDatabasesPath();
    String path = join(databasePath, "pharma.db");
    return await openDatabase(path,
        version: 1,
        onOpen: (db) {},
        onCreate: _onCreateDb,
        onConfigure: _onConfigure);
  }

  void _onCreateDb(Database db, int newVersion) async {
    // Create table medecin
    await db.execute("CREATE TABLE $tableMedecin ("
        "$_columnid INTEGER PRIMARY KEY,"
        "$_columnusername TEXT,"
        "$_columnnompassword TEXT"
        ")");

    await db.execute("CREATE TABLE $tableMedicament "
        "($columncode_Med INTEGER PRIMARY KEY, "
        "$columnnom_Med TEXT , $columnquantite TEXT,"
        " $columnlaboratoire TEXT"
        ")");

    await db.insert(tableMedecin,
        {"$_columnusername": "bicho", "$_columnnompassword": "test"});
  }

  Future _onConfigure(Database db) async {
    await db.execute('PRAGMA foreign_keys = ON');
  }

  Future<Medecin> loginMedecin(String username, String password) async {
    print(username);
    print(password);
    final database = await this.database;
    List<Map<String, dynamic>> results = await database.query(
      tableMedecin,
      where: "$_columnusername = ? and $_columnnompassword = ?",
      whereArgs: [username, password],
      limit: 1,
    );
    print(results);
    if (results.length > 0){
      return Medecin.fromMap(results.first);
    }
    return null;

  }
}
