import 'package:flutter/material.dart';

class Regles {
  //les colones de table student

  String _id;

  double _min_val;
  double _max_val;

  //=====clé etrangers====
  int _FKmedid;
  //un constructeur pour remplir le table
  Regles(
    this._FKmedid,
    this._id,
    this._min_val,
    this._max_val,
  );
  Regles.map(dynamic obj) {
    this._id = obj['id'];
    this._min_val = obj['min_val'];
    this._max_val = obj['max_val'];
    this._FKmedid = obj['FKmedid'];
  }

  //car les champs sont privée en met ca pour faciliter l acceder a eux

  String get id => _id;

  double get min_val => _min_val;
  double get max_val => _max_val;
  int get FKmedid => _FKmedid;

  Map<String, dynamic> toMap() {
    var map = new Map<String, dynamic>();

    map['id'] = _id;
    map['min_val'] = _min_val;
    map['max_val'] = _max_val;

    // map['FKmedid'] = _FKmedid;
    if (FKmedid != null) {
      map['FKmedid'] = _FKmedid;
    }

    return map;
  }

  Regles.fromMap(Map<String, dynamic> map) {
    this._id = map['nom_labo'];

    this._min_val = map['min_val'];
    this._max_val = map['max_val'];
    this._FKmedid = map['FKmedid'];
  }
}