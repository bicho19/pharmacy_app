import 'package:flutter/material.dart';

class Medicament {
  //les colones de table student
  int _code_medicament;
  String _nom;
  int _laboratoire;
  double _qualite;
  //un constructeur pour remplir le table
  Medicament(
    this._nom,
    this._laboratoire,
    this._qualite,
  );

  Medicament.map(dynamic obj) {
    this._nom = obj['nom'];
    this._laboratoire = obj['laboratoire'];
    this._qualite = obj['qualite'];
    this._code_medicament = obj['code_medicament'];
  }

  //car les champs sont privée en met ca pour faciliter l acceder a eux
  int get code_medicament => _code_medicament;
  String get nom => _nom;
  int get laboratoire => _laboratoire;
  double get qualite => _qualite;
  Map<String, dynamic> toMap() {
    var map = new Map<String, dynamic>();
    map['nom'] = _nom;
    map['laboratoire'] = _laboratoire;
    map['qualite'] = _qualite;
    if (code_medicament != null) {
      map['code_medicament'] = _code_medicament;
    }
    return map;
  }

  Medicament.fromMap(Map<String, dynamic> map) {
    this._nom = map['nom'];
    this._laboratoire = map['laboratoire'];
    this._qualite = map['qualite'];
    this._code_medicament = map['code_medicament'];
  }
}