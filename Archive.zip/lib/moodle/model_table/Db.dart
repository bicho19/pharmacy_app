import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:kmedica_pfe/moodle/Medecin.dart';
import 'package:kmedica_pfe/moodle/model_table/medcin.dart';
import 'package:kmedica_pfe/moodle/model_table/patient.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import 'Regles.dart';
import 'medicament.dart';



class DatabaseHelper {
 //cree une instance
  static final DatabaseHelper _instance = new DatabaseHelper.internal();

  factory DatabaseHelper() => _instance;
  static Database _db;
  //la declaration des attributs des tableaux pour eviter de tamber en erreur d'ortographe
  //tableau medecin=============================================
  final String tableMedecin = 'tableMedecin';
  final String _columnid = 'id';
  final String _columnusername = 'username';
  final String _columnnompassword = 'password';
  
//tableau medicament=============================================
  final String tableMed = 'tableMedicament';
  final String columncode_Med = 'code_medicament';
  final String columnnom_Med = 'nom';
  final String columnlaboratoire = 'laboratoire';
  final String columnquantite = 'quantite';
  
  
  //tableau Regles==========================================
  final String tableregles = 'Regles';
  final String id_reg = 'id';
  final String columnmin_val = 'min_val';
  final String columnmax_val = 'max_val';
  
 
  
  //tableau patient============================================================
  final String tablepatient = 'tablePatient';
  final String columnIdPatient = 'id_patient';
  final String columnnom_patient = 'nom_patient';
  final String columnprenom_patient = 'prenom_patient';
  final String columnage = 'age';
  final String columnPoids = 'poids';
  final String columnsex = 'sex';
  final String adresse = 'adresse';
  final String columnposologie = 'posologie';
  final String columnreduction = 'reduction';
  
  
  //les cle etrangers========================================================
  final String FKmedid = 'FKmedId';
  final String FKmedid2 = 'FKmedid2';
 
  final String FKpatientid = 'FKpatientid';
 
  //fonction qui cree une db
  Future<Database> get db async {
        if (_db != null) {
      return _db;



    }
    _db = await initDb();
    return _db;
  }

  DatabaseHelper.internal();

  get columnadresse => null;

  initDb() async {
    Directory documentDirectory = await getApplicationDocumentsDirectory();
    String path = join(
        documentDirectory.path, "maindb.db"); //home://directory/files/maindb.db
    var ourdb = await openDatabase(path, version: 1, onCreate: _onCreate);
    return ourdb;
  }

  void _onCreate(Database db, int version) async {
    debugPrint('Database OnCreate');

    // Win raho rable medecin ????



    //table medicament
    await db.execute(
      "CREATE TABLE $tableMed($columncode_Med INTEGER PRIMARY KEY , $columnnom_Med TEXT , $columnquantite TEXT , $columnlaboratoire TEXT)",
    );
    debugPrint('table  medicament OnCreate');

    //table Regles
    await db.execute(
      "CREATE TABLE $tableregles($_columnid TEXT,$columnmin_val REAL,$columnmax_val REAL ) ON DELETE CASCADE)",
    );
    debugPrint('Regles OnCreate');
    //table Patient
    await db.execute(
      "CREATE TABLE $tablepatient($columnIdPatient INTEGER PRIMARY KEY autoincrement,$columnnom_patient TEXT, $columnprenom_patient TEXT,$columnage INTEGER,$columnPoids INTEGER,$columnsex TEXT,$columnadresse TEXT,$columnposologie TEXT,$columnreduction TEXT )",
    );
    debugPrint('  patient OnCreate');
    }


    // Login medecin
  Future<Medecin> loginMedecin(String username, String password) async {
    Database database = await db;
    List<Map> maps = await database.query(tableMedecin,
        where: '$_columnusername = ? & $_columnnompassword = ?',
        whereArgs: [username, password]);
    if (maps.length > 0) {
      return Medecin.fromMap(maps.first);
    }
    return null;
  }

  

  

//CRUD CREATE READ UPDATE DELETE
  //==============================CRUD MEDICAMENT1 ================================================================
//insirer fonction
  Future<int> insertMedicament(Medicament med) async {
    var dbMedicament = await db;
    int res = await dbMedicament.insert("$tableMed", med.toMap());

    return res;
  }

  //aficher tout les medicaments
  Future<List> getAllMed() async {
    var dbMedicament = await db;
    var result = await dbMedicament.rawQuery("SELECT * FROM $tableMed");
    return result.toList();
  }

  //afficher un medicament
  Future<Medicament> getMed(int id) async {
    var dbMedicament = await db;
    var result = await dbMedicament
        .rawQuery("SELECT * FROM $tableMed WHERE $columncode_Med =$id");
    if (result.length == 0) return null;
    return new Medicament.fromMap(result.first);
  }

  //chercher un medicament
  Future<Medicament> chercherMed(String nom) async {
    var dbMedicament = await db;
    var result = await dbMedicament
        .rawQuery("SELECT * FROM $tableMed WHERE $columncode_Med LIKE '$nom%' ");
    if (result.length == 0) return null;
    return new Medicament.fromMap(result.first);
  }

  //supprimer un medicament
  Future<int> supprimerMed(int id) async {
    var dbMedicament = await db;
    return await dbMedicament
        //? veut dire que on le connait pas pour le moment
        .delete(tableMed, where: "$columncode_Med = ?", whereArgs: [id]);
  }

  //modifier medicament
  Future<int> modifierMed(Medicament med) async {
    var dbMedicament = await db;
    //? veut dire que on le connait pas pour le moment
    return await dbMedicament.update(tableMed, med.toMap(),
        where: "$columncode_Med = ?", whereArgs: [med.code_medicament]);
  }

  //==============================CRUD Regles 2 ================================================================
//insirer fonction
  Future<int> insertDetailMedicament(Regles detMed) async {
    var dbMedicament = await db;

    int res = await dbMedicament.insert("$tableregles", detMed.toMap());
    return res;
  }

  Future<Regles> getMedDetail(int id) async {
    var dbMedicament = await db;
    var result = await dbMedicament
        .rawQuery("SELECT * FROM $tableregles WHERE $FKmedid =$id");
    if (result.length == 0) return null;
    return new Regles.fromMap(result.first);
  }

  //aficher tout les medicaments
  Future<List> getAllDetailMed() async {
    var dbMedicament = await db;
    var result = await dbMedicament.rawQuery("SELECT * FROM $tableregles");
    return result.toList();
  }

  //supprimer un medicament
  Future<int> supprimerDetailMed(int id) async {
    var dbMedicament = await db;
    return await dbMedicament
        //? veut dire que on le connait pas pour le moment
        .delete(tableregles, where: "$FKmedid = ?", whereArgs: [id]);
  }

   //modifier medicament
  Future<int> modifierDetailMed(Medicament) async {
    var dbMedicament = await db;
    return await dbMedicament
        //? veut dire que on le connait pas pour le moment
        .update(tableMed, Medicament.toMap(),
            where: "$FKmedid = ?", whereArgs: [Medicament.FKmedId]);
  }

  //==============================CRUD patient 3================================================================
//insirer fonction
  Future<int> insertPatient(Patient pat) async {
    var dbMedicament = await db;
    int res = await dbMedicament.insert("$tablepatient", pat.toMap());
    return res;
  }

  //aficher tout
  Future<List> getAllpatient() async {
    var dbMedicament = await db;
    var result = await dbMedicament.rawQuery("SELECT * FROM $tablepatient");
    return result.toList();
  }

//chercher un medicament
  Future<Patient> chercherPatient(String nom) async {
    var dbMedicament = await db;
    var result = await dbMedicament.rawQuery(
        "SELECT * FROM $tablepatient WHERE $columnnom_patient LIKE '$nom' ");
    if (result.length == 0) return null;
    return new Patient.fromMap(result.first);
  }

  //afficher un patient
  Future<Patient> getPatient(int id) async {
    var dbMedicament = await db;
    var result = await dbMedicament
        .rawQuery("SELECT * FROM $tablepatient WHERE $columnIdPatient =$id");
    if (result.length == 0) return null;
    return new Patient.fromMap(result.first);
  }

  //supprimer
  Future<int> supprimerpatient(int id) async {
    var dbMedicament = await db;
    return await dbMedicament
        //? veut dire que on le connait pas pour le moment
        .delete(tablepatient, where: "$columnIdPatient= ?", whereArgs: [id]);
  }

  //modifier
  Future<int> modifierpatient(Patient pat) async {
    var dbMedicament = await db;
    return await dbMedicament
        //? veut dire que on le connait pas pour le moment
        .update(tablepatient, pat.toMap(),
            where: "$columnIdPatient = ?", whereArgs: [pat.id_patient]);
  }
  
  //fermer la base des donnee
  Future fermer() async {
    var dbMedicament = await db;
    return dbMedicament.close();
  }

}