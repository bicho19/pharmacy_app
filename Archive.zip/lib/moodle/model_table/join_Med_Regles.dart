import 'package:flutter/material.dart';

class Join_Med_Regles {
  //les colones de table student
  int _code_medicament;
  String _nom;
  String _laboratoire;
  int _quantite;
  //les colones de table calcul
  String _id;
  int _min_val;

  int _max_val;
  //=====clé etrangers====
  int _FKmedid;
  //un constructeur pour remplir le table
  Join_Med_Regles(
    this._nom,
    this._quantite,
    this._laboratoire,
    this._id,
    this._min_val,
    this._max_val,
    this._FKmedid,
  );

  Join_Med_Regles.map(dynamic obj) {
    this._nom = obj['nom'];
    this._quantite = obj['quantite'];
    this._laboratoire = obj['laboratoire'];
    this._code_medicament = obj['code_medicament'];
    this._id = obj['id'];
    this._min_val = obj['min_val'];
    this._max_val = obj['max_val'];
    this._FKmedid = obj['FKmedid'];
  }

  //car les champs sont privée en met ca pour faciliter l acceder a eux
  int get code_medicament => _code_medicament;
  String get nom => _nom;
  int get quantite => _quantite;
  String get laboratoire => _laboratoire;
  String get id => _id;
  int get min_val => _min_val;

  int get max_val => _max_val;
  int get FKmedid => _FKmedid;

  Map<String, dynamic> toMap() {
    var map = new Map<String, dynamic>();
    map['nom'] = _nom;
    map['quantite'] = _quantite;
    map['laboratoiren'] = _laboratoire;
    map['id'] = _id;
    map['min_val'] = _min_val;
    map['max_val'] = _max_val;

    map['FKmedid'] = _FKmedid;
    if (code_medicament != null) {
      map['id_medicament'] = _code_medicament;
    }
    return map;
  }

  Join_Med_Regles.fromMap(Map<String, dynamic> map) {
    this._nom = map['nom'];
    this._quantite = map['quantite'];
    this._laboratoire = map['laboratoire'];
    this._code_medicament = map['code_medicament'];
    this._id = map['id'];
    this._min_val = map['min_val'];
    this._max_val = map['max_val'];

    this._FKmedid = map['FKmedid'];
  }
}
