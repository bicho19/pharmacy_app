import 'package:flutter/material.dart';

class Patient {
  //les colones de table student
  int _id_patient;
  String _nom_patient;
  String _prenom_patient;
  int _age;
  int _poids;
  String _sex;
  String _adresse;
  String _posologie;
  String _reduction;
  //un constructeur pour remplir le table
  Patient(
    this._id_patient,
    this._nom_patient,
    this._prenom_patient,
    this._age,
    this._poids,
    this._sex,
    this._adresse,
    this._posologie,
    this._reduction,
  );

  Patient.map(dynamic obj) {
    this._nom_patient = obj['nom_patient'];
    this._prenom_patient = obj['prenom_patient'];

    this._poids = obj['poids'];
    this._age = obj['age'];
    this._sex = obj['sex'];
    this._adresse = obj['adresse'];
    this._posologie = obj['posologie'];
    this._reduction = obj['reduction'];
    this._id_patient = obj['id_patient'];
  }

  //car les champs sont privée en met ca pour faciliter l acceder a eux

  int get id_patient => _id_patient;
  String get nom_patient => _nom_patient;
  String get prenom_patient => _prenom_patient;
  int get age => _age;
  int get poids => _poids;
  String get sex => _sex;
  String get adresse => _adresse;
  String get posologie => _posologie;
  String get reduction => _reduction;

  Map<String, dynamic> toMap() {
    var map = new Map<String, dynamic>();
    map['nom_patient'] = _nom_patient;
    map['prenom_patient'] = _prenom_patient;
    map['age'] = _age;
    map['poids'] = _poids;
    map['sex'] = _sex;
    map['adresse'] = _adresse;
    map['posologie'] = _posologie;
    map['reduction'] = _reduction;

    if (id_patient != null) {
      map['id_patient'] = _id_patient;
    }
    return map;
  }

  Patient.fromMap(Map<String, dynamic> map) {
    this._nom_patient = map['nom_patient'];
    this._prenom_patient = map['prenom_patient'];
    this._age = map['age'];
    this._poids = map['poids'];
    this._sex = map['sex'];
    this._adresse = map['adresse'];
    this._posologie = map['posologie'];
    this._reduction = map['reduction'];
    this._id_patient = map['id_patient'];
  }
}
