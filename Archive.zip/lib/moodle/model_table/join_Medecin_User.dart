import 'package:flutter/material.dart';

class Join_Medecin_User {
  //les colones de table student
 
  String _username;
  String _password;
  String _email;
  String _sexe;
  //les colones de table User
  String _secret;
  String _mail;

  
  //=====clé etrangers====
     String _FKmedId2;
  //un constructeur pour remplir le table
  Join_Medecin_User(
    this._username,
    this._password,
    this._email,
    this._sexe,
    this._secret,
    this._mail,
    this._FKmedId2,
  );

  Join_Medecin_User.map(dynamic obj) {
    this._username = obj['username'];
    this._password = obj['password'];
    this._email = obj['email'];
    this._sexe = obj['sexe'];
    this._secret = obj['secret'];
    this._mail = obj['mail'];
   
    this._FKmedId2 = obj['FKmedId2'];
  }

  //car les champs sont privée en met ca pour faciliter l acceder a eux
 String get username => _username;
  String get password=> _password;
  String get email => _email;
  String get sexe => _sexe;
  
  String get secret => _secret;

  String get mail => _mail;
  String get FKmedId2 => _FKmedId2;

  Map<String, dynamic> toMap() {
    var map = new Map<String, dynamic>();
    map['username'] = _username;
    map['password'] = _password;
    map['email'] = _email;
    map['sexe'] = _sexe;
    map['secret'] = _secret;
    map['mail'] = _mail;

    map['FKmedId2'] = _FKmedId2;
    if (username != null) {
      map['id_medicament'] = _username;
    }
    return map;
  }

  Join_Medecin_User.fromMap(Map<String, dynamic> map) {
    this._username = map['username'];
    this._password = map['password'];
    this._email = map['email'];
    this._sexe = map['sexe'];
    this._secret = map['secret'];
    this._mail = map['mail'];
    

    this._FKmedId2 = map['FKmedId2'];
  }
}