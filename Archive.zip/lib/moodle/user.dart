class User{
  
  
  String _secret;
  String _mail;
  

  User( this._secret, this._mail);

  User.fromMap(dynamic obj) {
    
    this._secret = obj['secret'];
    this._mail = obj['mail'];
    
  }

 
  String get secret => _secret;
  String get mail => _mail;
  

  Map<String, dynamic> toMap() {
    var map = new Map<String, dynamic>();
 
    map["secret"] = _secret;
    map["mail"] = _mail;
    
    return map;
  }
}