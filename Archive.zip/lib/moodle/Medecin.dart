  
class Medecin {
  
  String _username;
  String _password;
  String _email;
  String _sexe;
  //cle etrangére
  int FKmesdId2;

  Medecin(this._username, this._password, this._email, this._sexe);

  Medecin.fromMap(dynamic obj) {
    this._username = obj['username'];
    this._password = obj['password'];
    this._email = obj['email'];
    this._sexe = obj['sexe'];
  }

  String get username => _username;
  String get password => _password;
  String get email => _email;
  String get sexe => _sexe;

  Map<String, dynamic> toMap() {
    var map = new Map<String, dynamic>();
    map["username"] = _username;
    map["password"] = _password;
    map["email"] = _email;
    map["sexe"] = _sexe;
    return map;
  }
}