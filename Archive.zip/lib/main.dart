import 'package:flutter/material.dart';
import 'package:kmedica_pfe/loginsignupscreen.dart';
import 'package:kmedica_pfe/moodle/model_table/Db.dart';
import 'package:kmedica_pfe/utils/database_provider.dart';

Future<void> main() async {
  // Avoid errors caused by flutter upgrade.
  // Importing 'package:flutter/widgets.dart' is required.
  WidgetsFlutterBinding.ensureInitialized();
  DBProvider dbProvider = DBProvider.db;

  await dbProvider.database;

  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginSignupScreen(),
    ),
  );
}
