package com.example.kmedica_pfe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
